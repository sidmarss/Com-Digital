using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace COMUNIDAD_DIGITAL
{
    public partial class InicioSesion : Form
    {
        string conexion = "Server=localhost;Database=comunidad_digital;Uid=root;Pwd=1906;";

        public InicioSesion()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void INICIO_SESION_Load(object sender, EventArgs e)
        {

        }

        private void btnREGISTRARME_Click(object sender, EventArgs e)
        {
            REGISTRO registro = new REGISTRO();
            registro.Show();
            this.Hide();
        }

        private void btnINICIARSESION_Click(object sender, EventArgs e)
        {
            string correo = txtCorreo.Text.Trim();
            string contrasena = txtContrasena.Text.Trim();

            if (string.IsNullOrWhiteSpace(correo) || string.IsNullOrWhiteSpace(contrasena))
            {
                MessageBox.Show("Por favor ingresa tu correo y contrase�a.");
                return;
            }

            using (MySqlConnection con = new MySqlConnection(conexion))
            {
                string query = "SELECT COUNT(*) FROM usuarios WHERE correo = @correo AND contrasena = @contrase�a";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@correo", correo);
                cmd.Parameters.AddWithValue("@contrase�a", contrasena);

                try
                {
                    con.Open();
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count > 0)
                    {
                        MessageBox.Show("Inicio de sesi�n exitoso.");
                        Menu menu = new Menu();
                        menu.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Correo o contrase�a incorrectos.");
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error al conectar con la base de datos: " + ex.Message);
                }
            }
        }

        private void txtCORREO_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
