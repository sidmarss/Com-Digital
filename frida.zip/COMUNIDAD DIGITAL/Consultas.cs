﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace COMUNIDAD_DIGITAL
{
    public partial class CONSULTAS : Form
    {
        
        string connectionString = "server=localhost;database=comunidad_digital;uid=root;pwd=1906;";

        public CONSULTAS()
        {
            InitializeComponent();
        }

        private void CONSULTAS_Load(object sender, EventArgs e)
        {
            MostrarConsultas();
        }

        private void MostrarConsultas()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM consultas";
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }

        private void InsertarConsulta(string nombre, string padecimiento)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO consultas (nombre, padecimiento) VALUES (@nombre, @padecimiento)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@padecimiento", padecimiento);
                        cmd.ExecuteNonQuery();
                    }
                }

                MostrarConsultas(); // Refrescar DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al insertar: " + ex.Message);
            }
        }

        private void btnRealizarConsulta_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string padecimiento = txtPadecimiento.Text.Trim();

            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(padecimiento))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            InsertarConsulta(nombre, padecimiento);
            txtNombre.Clear();
            txtPadecimiento.Clear();
        }

        // Si tienes más eventos de UI puedes dejarlos aquí (por ejemplo, clicks en imágenes o etiquetas)
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Deja vacío si no lo necesitas
        }

        private void label2_Click(object sender, EventArgs e)
        {
            // Deja vacío si no lo necesitas
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Este evento solo si necesitas interactuar con filas/celdas
        }
    }
}
