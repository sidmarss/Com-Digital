﻿internal class SqlConnection
{
    private object conexion;

    public SqlConnection(object conexion)
    {
        this.conexion = conexion;
    }
}