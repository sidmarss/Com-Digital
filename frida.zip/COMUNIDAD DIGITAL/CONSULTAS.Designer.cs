﻿namespace COMUNIDAD_DIGITAL
{
    partial class CONSULTAS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Bienvenido = new Label();
            Nombre = new Label();
            Padecimiento = new Label();
            txtNombre = new TextBox();
            txtPadecimiento = new TextBox();
            btnRealizarConsulta = new Button();
            dataGridView1 = new DataGridView();
            RealizarConsulta = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // Bienvenido
            // 
            Bienvenido.AutoSize = true;
            Bienvenido.BackColor = Color.LightSteelBlue;
            Bienvenido.BorderStyle = BorderStyle.FixedSingle;
            Bienvenido.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Bienvenido.Location = new Point(333, 29);
            Bienvenido.Name = "Bienvenido";
            Bienvenido.Size = new Size(393, 30);
            Bienvenido.TabIndex = 0;
            Bienvenido.Text = "BIENVENIDO A COMUNIDAD DIGITAL ";
            // 
            // Nombre
            // 
            Nombre.AutoSize = true;
            Nombre.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Nombre.Location = new Point(41, 215);
            Nombre.Name = "Nombre";
            Nombre.Size = new Size(87, 23);
            Nombre.TabIndex = 1;
            Nombre.Text = "NOMBRE ";
            Nombre.Click += label2_Click;
            // 
            // Padecimiento
            // 
            Padecimiento.AutoSize = true;
            Padecimiento.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Padecimiento.Location = new Point(41, 324);
            Padecimiento.Name = "Padecimiento";
            Padecimiento.Size = new Size(136, 23);
            Padecimiento.TabIndex = 4;
            Padecimiento.Text = "PADECIMIENTO ";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(41, 241);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(192, 27);
            txtNombre.TabIndex = 5;
            // 
            // txtPadecimiento
            // 
            txtPadecimiento.Location = new Point(41, 350);
            txtPadecimiento.Name = "txtPadecimiento";
            txtPadecimiento.Size = new Size(192, 27);
            txtPadecimiento.TabIndex = 8;
            // 
            // btnRealizarConsulta
            // 
            btnRealizarConsulta.BackColor = Color.LightSteelBlue;
            btnRealizarConsulta.Location = new Point(41, 495);
            btnRealizarConsulta.Name = "btnRealizarConsulta";
            btnRealizarConsulta.Size = new Size(192, 44);
            btnRealizarConsulta.TabIndex = 9;
            btnRealizarConsulta.Text = "REALIZAR CONSULTA";
            btnRealizarConsulta.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(387, 126);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(588, 413);
            dataGridView1.TabIndex = 10;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // RealizarConsulta
            // 
            RealizarConsulta.AutoSize = true;
            RealizarConsulta.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RealizarConsulta.Location = new Point(41, 101);
            RealizarConsulta.Name = "RealizarConsulta";
            RealizarConsulta.Size = new Size(203, 23);
            RealizarConsulta.TabIndex = 11;
            RealizarConsulta.Text = "REALIZA TU CONSULTA:";
            // 
            // CONSULTAS
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(1041, 769);
            Controls.Add(RealizarConsulta);
            Controls.Add(dataGridView1);
            Controls.Add(btnRealizarConsulta);
            Controls.Add(txtPadecimiento);
            Controls.Add(txtNombre);
            Controls.Add(Padecimiento);
            Controls.Add(Nombre);
            Controls.Add(Bienvenido);
            Name = "CONSULTAS";
            Text = "CONSULTAS";
            Load += CONSULTAS_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Bienvenido;
        private Label Nombre;
        private Label Padecimiento;
        private TextBox txtNombre;
        private TextBox txtPadecimiento;
        private Button btnRealizarConsulta;
        private DataGridView dataGridView1;
        private Label RealizarConsulta;
    }
}