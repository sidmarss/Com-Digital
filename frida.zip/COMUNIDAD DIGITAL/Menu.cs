﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMUNIDAD_DIGITAL
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panelapp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnConsultas_Click(object sender, EventArgs e)
        {
            CONSULTAS consultas = new CONSULTAS();
            consultas.Show();
        }

        private void btnregistrociudadano_Click(object sender, EventArgs e)
        {
            RegistroCiudadano registroCiudadano = new RegistroCiudadano();
            registroCiudadano.Show();
        }

        private void btnRegistroMedico_Click(object sender, EventArgs e)
        {
            RegistroMedico registroMedico = new RegistroMedico();
            registroMedico.Show();
        }

        private void panel_menu_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
