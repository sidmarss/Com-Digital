﻿namespace COMUNIDAD_DIGITAL
{
    partial class InicioSesion
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            Correo = new Label();
            Contraseña = new Label();
            txtCorreo = new TextBox();
            txtContrasena = new TextBox();
            btnIniciarSesion = new Button();
            btnRegistrarme = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightSteelBlue;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ImageAlign = ContentAlignment.TopCenter;
            label1.Location = new Point(239, 27);
            label1.Margin = new Padding(8, 0, 8, 0);
            label1.Name = "label1";
            label1.Size = new Size(564, 43);
            label1.TabIndex = 0;
            label1.Text = "BIENVENIDO A COMUNIDAD DIGITAL ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(431, 116);
            label2.Name = "label2";
            label2.Size = new Size(175, 28);
            label2.TabIndex = 1;
            label2.Text = "INICIO DE SESION ";
            // 
            // Correo
            // 
            Correo.AutoSize = true;
            Correo.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Correo.Location = new Point(243, 217);
            Correo.Name = "Correo";
            Correo.Size = new Size(92, 28);
            Correo.TabIndex = 2;
            Correo.Text = "CORREO ";
            // 
            // Contraseña
            // 
            Contraseña.AutoSize = true;
            Contraseña.BackColor = Color.Transparent;
            Contraseña.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Contraseña.Location = new Point(198, 298);
            Contraseña.Name = "Contraseña";
            Contraseña.Size = new Size(137, 28);
            Contraseña.TabIndex = 3;
            Contraseña.Text = "CONTRASEÑA";
            // 
            // txtCorreo
            // 
            txtCorreo.Font = new Font("Segoe UI Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCorreo.Location = new Point(341, 214);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(381, 31);
            txtCorreo.TabIndex = 4;
            txtCorreo.TextChanged += txtCORREO_TextChanged;
            // 
            // txtContrasena
            // 
            txtContrasena.Font = new Font("Segoe UI Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtContrasena.Location = new Point(341, 295);
            txtContrasena.Name = "txtContrasena";
            txtContrasena.Size = new Size(381, 31);
            txtContrasena.TabIndex = 5;
            // 
            // btnIniciarSesion
            // 
            btnIniciarSesion.BackColor = Color.LightSteelBlue;
            btnIniciarSesion.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnIniciarSesion.Location = new Point(387, 425);
            btnIniciarSesion.Name = "btnIniciarSesion";
            btnIniciarSesion.Size = new Size(299, 39);
            btnIniciarSesion.TabIndex = 6;
            btnIniciarSesion.Text = "INICIAR SESION ";
            btnIniciarSesion.UseVisualStyleBackColor = false;
            btnIniciarSesion.Click += btnINICIARSESION_Click;
            // 
            // btnRegistrarme
            // 
            btnRegistrarme.BackColor = Color.LightSteelBlue;
            btnRegistrarme.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistrarme.Location = new Point(387, 509);
            btnRegistrarme.Name = "btnRegistrarme";
            btnRegistrarme.Size = new Size(299, 42);
            btnRegistrarme.TabIndex = 7;
            btnRegistrarme.Text = "REGISTRARME ";
            btnRegistrarme.UseVisualStyleBackColor = false;
            btnRegistrarme.Click += btnREGISTRARME_Click;
            // 
            // InicioSesion
            // 
            AutoScaleDimensions = new SizeF(20F, 40F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1035, 616);
            Controls.Add(btnRegistrarme);
            Controls.Add(btnIniciarSesion);
            Controls.Add(txtContrasena);
            Controls.Add(txtCorreo);
            Controls.Add(Contraseña);
            Controls.Add(Correo);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 19.8000011F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ActiveCaptionText;
            Margin = new Padding(8, 6, 8, 6);
            Name = "InicioSesion";
            Text = "INICIO_SESION";
            Load += INICIO_SESION_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label Correo;
        private Label Contraseña;
        private TextBox txtCorreo;
        private TextBox txtContrasena;
        private Button btnIniciarSesion;
        private Button btnRegistrarme;
    }
}