﻿namespace COMUNIDAD_DIGITAL
{
    partial class Menu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panel_menu = new Panel();
            btnConsulta = new Button();
            btnRegistroMedico = new Button();
            btnRegistroCiudadano = new Button();
            panelapp = new Panel();
            Bienvenido = new Label();
            logo = new PictureBox();
            panel_menu.SuspendLayout();
            panelapp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            SuspendLayout();
            // 
            // panel_menu
            // 
            panel_menu.BackColor = Color.LightSteelBlue;
            panel_menu.Controls.Add(btnConsulta);
            panel_menu.Controls.Add(btnRegistroMedico);
            panel_menu.Controls.Add(btnRegistroCiudadano);
            panel_menu.Dock = DockStyle.Left;
            panel_menu.Location = new Point(0, 0);
            panel_menu.Name = "panel_menu";
            panel_menu.Size = new Size(263, 419);
            panel_menu.TabIndex = 0;
            // 
            // btnConsulta
            // 
            btnConsulta.Dock = DockStyle.Top;
            btnConsulta.FlatAppearance.BorderSize = 0;
            btnConsulta.FlatStyle = FlatStyle.Flat;
            btnConsulta.Font = new Font("Sitka Text", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConsulta.Location = new Point(0, 214);
            btnConsulta.Name = "btnConsulta";
            btnConsulta.Size = new Size(263, 87);
            btnConsulta.TabIndex = 3;
            btnConsulta.Text = "CONSULTA";
            btnConsulta.UseVisualStyleBackColor = true;
            btnConsulta.Click += btnConsultas_Click;
            // 
            // btnRegistroMedico
            // 
            btnRegistroMedico.Dock = DockStyle.Top;
            btnRegistroMedico.FlatAppearance.BorderSize = 0;
            btnRegistroMedico.FlatStyle = FlatStyle.Flat;
            btnRegistroMedico.Font = new Font("Sitka Text", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistroMedico.Location = new Point(0, 101);
            btnRegistroMedico.Name = "btnRegistroMedico";
            btnRegistroMedico.Size = new Size(263, 113);
            btnRegistroMedico.TabIndex = 2;
            btnRegistroMedico.Text = "REGISTRO MEDICO";
            btnRegistroMedico.UseVisualStyleBackColor = true;
            btnRegistroMedico.Click += btnRegistroMedico_Click;
            // 
            // btnRegistroCiudadano
            // 
            btnRegistroCiudadano.Dock = DockStyle.Top;
            btnRegistroCiudadano.FlatAppearance.BorderSize = 0;
            btnRegistroCiudadano.FlatStyle = FlatStyle.Flat;
            btnRegistroCiudadano.Font = new Font("Sitka Text", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistroCiudadano.Location = new Point(0, 0);
            btnRegistroCiudadano.Name = "btnRegistroCiudadano";
            btnRegistroCiudadano.Size = new Size(263, 101);
            btnRegistroCiudadano.TabIndex = 1;
            btnRegistroCiudadano.Text = "REGISTRO CIUDADANO";
            btnRegistroCiudadano.UseVisualStyleBackColor = true;
            btnRegistroCiudadano.Click += btnregistrociudadano_Click;
            // 
            // panelapp
            // 
            panelapp.BackColor = SystemColors.ButtonHighlight;
            panelapp.Controls.Add(Bienvenido);
            panelapp.Controls.Add(logo);
            panelapp.Dock = DockStyle.Fill;
            panelapp.Location = new Point(263, 0);
            panelapp.Name = "panelapp";
            panelapp.Size = new Size(564, 419);
            panelapp.TabIndex = 1;
            panelapp.Paint += panelapp_Paint;
            // 
            // Bienvenido
            // 
            Bienvenido.AutoSize = true;
            Bienvenido.Font = new Font("Lucida Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Bienvenido.Location = new Point(106, 253);
            Bienvenido.Name = "Bienvenido";
            Bienvenido.Size = new Size(390, 23);
            Bienvenido.TabIndex = 1;
            Bienvenido.Text = "BIENVENIDO A COMUNIDAD DIGITAL";
            Bienvenido.Click += label1_Click;
            // 
            // logo
            // 
            logo.Image = Properties.Resources.LOGOOO;
            logo.Location = new Point(189, 48);
            logo.Name = "logo";
            logo.Size = new Size(189, 172);
            logo.SizeMode = PictureBoxSizeMode.Zoom;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(827, 419);
            Controls.Add(panelapp);
            Controls.Add(panel_menu);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Menu";
            panel_menu.ResumeLayout(false);
            panelapp.ResumeLayout(false);
            panelapp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel_menu;
        private Panel panelapp;
        private PictureBox logo;
        private Button btnRegistroCiudadano;
        private Button btnConsulta;
        private Button btnRegistroMedico;
        private Label Bienvenido;
    }
}