﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace COMUNIDAD_DIGITAL
{
    public partial class REGISTRO : Form
    {
        string conexion = "Server=localhost;Database=comunidad_digital;Uid=root;Pwd=1906;";

        public REGISTRO()
        {
            InitializeComponent();
        }

        private void btnREGISTRARME_Click(object sender, EventArgs e)
        {
            string correo = txtCorreo.Text.Trim();
            string nombre = txtNombre.Text.Trim();
            string contrasena = txtContrasena.Text.Trim();
            string confirmar = txtVerificarContrasena.Text.Trim();

            // Validaciones básicas
            if (string.IsNullOrWhiteSpace(correo) ||
                string.IsNullOrWhiteSpace(nombre) ||
                string.IsNullOrWhiteSpace(contrasena) ||
                string.IsNullOrWhiteSpace(confirmar))
            {
                MessageBox.Show("Por favor completa todos los campos.");
                return;
            }

            // Validación de correo electrónico
            if (!Regex.IsMatch(correo, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("El correo electrónico no tiene un formato válido.");
                return;
            }

            

            // Validación de contraseña (mínimo 6 caracteres, al menos una letra y un número)
            if (contrasena.Length < 6 ||
                !Regex.IsMatch(contrasena, @"[A-Za-z]") ||
                !Regex.IsMatch(contrasena, @"\d"))
            {
                MessageBox.Show("La contraseña debe tener al menos 6 caracteres, una letra y un número.");
                return;
            }

            if (contrasena != confirmar)
            {
                MessageBox.Show("Las contraseñas no coinciden.");
                return;
            }

            using (MySqlConnection con = new MySqlConnection(conexion))
            {
                string query = "INSERT INTO usuarios (correo, nombre, contraseña) VALUES (@correo, @nombre, @contraseña)";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@correo", correo);
                cmd.Parameters.AddWithValue("@nombre", nombre);
                cmd.Parameters.AddWithValue("@contraseña", contrasena);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Usuario registrado exitosamente.");
                    Menu menu = new Menu();
                    menu.Show();
                    this.Hide();
                }
                catch (MySqlException ex)
                {
                    if (ex.Number == 1062)
                        MessageBox.Show("Este correo ya está registrado.");
                    else
                        MessageBox.Show("Error al registrar usuario: " + ex.Message);
                }
            }
        }

        private void btnINICIARSESION_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            menu.Show();
            this.Hide();
        }

        private void REGISTRO_Load(object sender, EventArgs e)
        {

        }
    }
}
