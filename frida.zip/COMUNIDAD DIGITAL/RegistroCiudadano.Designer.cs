﻿namespace COMUNIDAD_DIGITAL
{
    partial class RegistroCiudadano
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label5 = new Label();
            textBox4 = new TextBox();
            label6 = new Label();
            textBox5 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            textBox6 = new TextBox();
            comboBox1 = new ComboBox();
            label10 = new Label();
            texCURP = new TextBox();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            label11 = new Label();
            label12 = new Label();
            textBox8 = new TextBox();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            textBox9 = new TextBox();
            label16 = new Label();
            label17 = new Label();
            label19 = new Label();
            label20 = new Label();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            label21 = new Label();
            label22 = new Label();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            label18 = new Label();
            textBox16 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(348, 9);
            label1.Name = "label1";
            label1.Size = new Size(340, 38);
            label1.TabIndex = 0;
            label1.Text = "REGISTRO CIUDADANO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(68, 106);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 1;
            label2.Text = "NOMBRE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(296, 106);
            label3.Name = "label3";
            label3.Size = new Size(142, 20);
            label3.TabIndex = 2;
            label3.Text = "APELLIDO PATERNO";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(536, 106);
            label4.Name = "label4";
            label4.Size = new Size(152, 20);
            label4.TabIndex = 3;
            label4.Text = "APELLIDO MATERNO ";
            label4.Click += label4_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(68, 129);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(190, 27);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(296, 129);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(190, 27);
            textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(536, 129);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(190, 27);
            textBox3.TabIndex = 6;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(39, 325);
            label5.Name = "label5";
            label5.Size = new Size(166, 20);
            label5.TabIndex = 7;
            label5.Text = "LOCALIDAD O CIUDAD ";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(39, 357);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(190, 27);
            textBox4.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(489, 325);
            label6.Name = "label6";
            label6.Size = new Size(64, 20);
            label6.TabIndex = 9;
            label6.Text = "ESTADO";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(489, 357);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(190, 27);
            textBox5.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(773, 184);
            label7.Name = "label7";
            label7.Size = new Size(101, 20);
            label7.TabIndex = 11;
            label7.Text = "ESTADO CIVIL";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(847, 106);
            label8.Name = "label8";
            label8.Size = new Size(45, 20);
            label8.TabIndex = 12;
            label8.Text = "SEXO";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(618, 184);
            label9.Name = "label9";
            label9.Size = new Size(49, 20);
            label9.TabIndex = 15;
            label9.Text = "EDAD";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(618, 207);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(94, 27);
            textBox6.TabIndex = 16;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "SOLTERO", "CASADO", "VIUDO", "DIVORCIADO", "UNION LIBRE " });
            comboBox1.Location = new Point(773, 209);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(403, 184);
            label10.Name = "label10";
            label10.Size = new Size(45, 20);
            label10.TabIndex = 18;
            label10.Text = "CURP";
            // 
            // texCURP
            // 
            texCURP.Location = new Point(403, 207);
            texCURP.Name = "texCURP";
            texCURP.Size = new Size(190, 27);
            texCURP.TabIndex = 19;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(783, 129);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(75, 24);
            radioButton2.TabIndex = 21;
            radioButton2.TabStop = true;
            radioButton2.Text = "MUJER";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(889, 129);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(91, 24);
            radioButton3.TabIndex = 22;
            radioButton3.TabStop = true;
            radioButton3.Text = "HOMBRE";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Checked = false;
            dateTimePicker1.Location = new Point(68, 207);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(277, 27);
            dateTimePicker1.TabIndex = 23;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(68, 184);
            label11.Name = "label11";
            label11.Size = new Size(173, 20);
            label11.TabIndex = 24;
            label11.Text = "FECHA DE NACIMIENTO ";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(262, 325);
            label12.Name = "label12";
            label12.Size = new Size(83, 20);
            label12.TabIndex = 25;
            label12.Text = "MUNICIPIO";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(262, 357);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(190, 27);
            textBox8.TabIndex = 26;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(28, 64);
            label13.Name = "label13";
            label13.Size = new Size(207, 28);
            label13.TabIndex = 27;
            label13.Text = "DATOS PERSONALES";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(28, 273);
            label14.Name = "label14";
            label14.Size = new Size(116, 28);
            label14.TabIndex = 28;
            label14.Text = "DOMICILIO";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(724, 325);
            label15.Name = "label15";
            label15.Size = new Size(118, 20);
            label15.TabIndex = 29;
            label15.Text = "NACIONALIDAD";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(724, 357);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(190, 27);
            textBox9.TabIndex = 30;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(39, 413);
            label16.Name = "label16";
            label16.Size = new Size(50, 20);
            label16.TabIndex = 31;
            label16.Text = "CALLE";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(204, 413);
            label17.Name = "label17";
            label17.Size = new Size(263, 20);
            label17.TabIndex = 32;
            label17.Text = "COLONIA,REGION O SUPERMANZANA";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(498, 413);
            label19.Name = "label19";
            label19.Size = new Size(240, 20);
            label19.TabIndex = 34;
            label19.Text = "CARACTERISTICAS DEL DOMICILIO";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(811, 413);
            label20.Name = "label20";
            label20.Size = new Size(201, 20);
            label20.TabIndex = 35;
            label20.Text = "REFERENCIAS DE DOMICILIO";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(39, 453);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(134, 27);
            textBox10.TabIndex = 36;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(204, 453);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(263, 27);
            textBox11.TabIndex = 37;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(507, 453);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(240, 27);
            textBox12.TabIndex = 38;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(811, 453);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(201, 27);
            textBox13.TabIndex = 39;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(39, 553);
            label21.Name = "label21";
            label21.Size = new Size(80, 20);
            label21.TabIndex = 40;
            label21.Text = "TELEFONO";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(277, 553);
            label22.Name = "label22";
            label22.Size = new Size(165, 20);
            label22.TabIndex = 41;
            label22.Text = "CORREO ELECTRONICO";
            // 
            // textBox14
            // 
            textBox14.Location = new Point(39, 586);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(190, 27);
            textBox14.TabIndex = 42;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(277, 586);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(227, 27);
            textBox15.TabIndex = 43;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(562, 553);
            label18.Name = "label18";
            label18.Size = new Size(91, 20);
            label18.TabIndex = 44;
            label18.Text = "OCUPACIÓN";
            // 
            // textBox16
            // 
            textBox16.Location = new Point(562, 586);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(227, 27);
            textBox16.TabIndex = 45;
            // 
            // button1
            // 
            button1.BackColor = Color.LightSteelBlue;
            button1.Location = new Point(372, 654);
            button1.Name = "button1";
            button1.Size = new Size(132, 41);
            button1.TabIndex = 46;
            button1.Text = "ATRAS";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.LightSteelBlue;
            button2.Location = new Point(534, 650);
            button2.Name = "button2";
            button2.Size = new Size(133, 45);
            button2.TabIndex = 47;
            button2.Text = "SIGUIENTE";
            button2.UseVisualStyleBackColor = false;
            // 
            // RegistroCiudadano
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1036, 724);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox16);
            Controls.Add(label18);
            Controls.Add(textBox15);
            Controls.Add(textBox14);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(textBox13);
            Controls.Add(textBox12);
            Controls.Add(textBox11);
            Controls.Add(textBox10);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(textBox9);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(textBox8);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(dateTimePicker1);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(texCURP);
            Controls.Add(label10);
            Controls.Add(comboBox1);
            Controls.Add(textBox6);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(textBox5);
            Controls.Add(label6);
            Controls.Add(textBox4);
            Controls.Add(label5);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "RegistroCiudadano";
            Text = "CIUDADANO";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Label label5;
        private TextBox textBox4;
        private Label label6;
        private TextBox textBox5;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textBox6;
        private ComboBox comboBox1;
        private Label label10;
        private TextBox texCURP;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private DateTimePicker dateTimePicker1;
        private Label label11;
        private Label label12;
        private TextBox textBox8;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox textBox9;
        private Label label16;
        private Label label17;
        private Label label19;
        private Label label20;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private Label label21;
        private Label label22;
        private TextBox textBox14;
        private TextBox textBox15;
        private Label label18;
        private TextBox textBox16;
        private Button button1;
        private Button button2;
    }
}