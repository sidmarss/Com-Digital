﻿namespace COMUNIDAD_DIGITAL
{
    partial class REGISTRO
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            label1 = new Label();
            CORREO = new Label();
            NOMBRE = new Label();
            CONTRASEÑA = new Label();
            VERIFICAR_CONTRASEÑA = new Label();
            txtCorreo = new TextBox();
            txtNombre = new TextBox();
            txtContrasena = new TextBox();
            txtVerificarContrasena = new TextBox();
            btnINICIARSESION = new Button();
            btnREGISTRARME = new Button();
            label7 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(251, 19);
            label1.Name = "label1";
            label1.Size = new Size(556, 43);
            label1.TabIndex = 0;
            label1.Text = "BIENVENIDO A COMUNIDAD DIGITAL";
            // 
            // CORREO
            // 
            CORREO.AutoSize = true;
            CORREO.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CORREO.Location = new Point(156, 139);
            CORREO.Name = "CORREO";
            CORREO.Size = new Size(97, 28);
            CORREO.TabIndex = 1;
            CORREO.Text = " CORREO ";
            // 
            // NOMBRE
            // 
            NOMBRE.AutoSize = true;
            NOMBRE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            NOMBRE.Location = new Point(622, 139);
            NOMBRE.Name = "NOMBRE";
            NOMBRE.Size = new Size(98, 28);
            NOMBRE.TabIndex = 2;
            NOMBRE.Text = "NOMBRE ";
            // 
            // CONTRASEÑA
            // 
            CONTRASEÑA.AutoSize = true;
            CONTRASEÑA.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CONTRASEÑA.Location = new Point(156, 264);
            CONTRASEÑA.Name = "CONTRASEÑA";
            CONTRASEÑA.Size = new Size(142, 28);
            CONTRASEÑA.TabIndex = 4;
            CONTRASEÑA.Text = "CONTRASEÑA ";
            // 
            // VERIFICAR_CONTRASEÑA
            // 
            VERIFICAR_CONTRASEÑA.AutoSize = true;
            VERIFICAR_CONTRASEÑA.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            VERIFICAR_CONTRASEÑA.Location = new Point(622, 264);
            VERIFICAR_CONTRASEÑA.Name = "VERIFICAR_CONTRASEÑA";
            VERIFICAR_CONTRASEÑA.Size = new Size(238, 28);
            VERIFICAR_CONTRASEÑA.TabIndex = 5;
            VERIFICAR_CONTRASEÑA.Text = "VERIFICAR CONTRASEÑA ";
            // 
            // txtCorreo
            // 
            txtCorreo.Font = new Font("Segoe UI Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCorreo.Location = new Point(156, 179);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(218, 31);
            txtCorreo.TabIndex = 6;
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Segoe UI Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNombre.Location = new Point(622, 179);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(214, 31);
            txtNombre.TabIndex = 7;
            // 
            // txtContrasena
            // 
            txtContrasena.Font = new Font("Segoe UI Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtContrasena.Location = new Point(156, 310);
            txtContrasena.Name = "txtContrasena";
            txtContrasena.Size = new Size(218, 31);
            txtContrasena.TabIndex = 9;
            // 
            // txtVerificarContrasena
            // 
            txtVerificarContrasena.Font = new Font("Segoe UI Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtVerificarContrasena.Location = new Point(622, 310);
            txtVerificarContrasena.Name = "txtVerificarContrasena";
            txtVerificarContrasena.Size = new Size(214, 31);
            txtVerificarContrasena.TabIndex = 10;
            // 
            // btnINICIARSESION
            // 
            btnINICIARSESION.BackColor = Color.LightSteelBlue;
            btnINICIARSESION.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnINICIARSESION.Location = new Point(251, 460);
            btnINICIARSESION.Name = "btnINICIARSESION";
            btnINICIARSESION.Size = new Size(199, 41);
            btnINICIARSESION.TabIndex = 11;
            btnINICIARSESION.Text = "INICIAR SESION ";
            btnINICIARSESION.UseVisualStyleBackColor = false;
            btnINICIARSESION.Click += btnINICIARSESION_Click;
            // 
            // btnREGISTRARME
            // 
            btnREGISTRARME.BackColor = Color.LightSteelBlue;
            btnREGISTRARME.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnREGISTRARME.Location = new Point(591, 460);
            btnREGISTRARME.Name = "btnREGISTRARME";
            btnREGISTRARME.Size = new Size(198, 41);
            btnREGISTRARME.TabIndex = 12;
            btnREGISTRARME.Text = "REGISTRARME ";
            btnREGISTRARME.UseVisualStyleBackColor = false;
            btnREGISTRARME.Click += btnREGISTRARME_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(433, 71);
            label7.Name = "label7";
            label7.Size = new Size(168, 31);
            label7.TabIndex = 13;
            label7.Text = "REGISTRARME ";
            // 
            // REGISTRO
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1034, 586);
            Controls.Add(label7);
            Controls.Add(btnREGISTRARME);
            Controls.Add(btnINICIARSESION);
            Controls.Add(txtVerificarContrasena);
            Controls.Add(txtContrasena);
            Controls.Add(txtNombre);
            Controls.Add(txtCorreo);
            Controls.Add(VERIFICAR_CONTRASEÑA);
            Controls.Add(CONTRASEÑA);
            Controls.Add(NOMBRE);
            Controls.Add(CORREO);
            Controls.Add(label1);
            Name = "REGISTRO";
            Text = "REGISTRO";
            Load += REGISTRO_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label CORREO;
        private Label NOMBRE;
        private Label CONTRASEÑA;
        private Label VERIFICAR_CONTRASEÑA;
        private TextBox txtCorreo;
        private TextBox txtNombre;
        private TextBox txtContrasena;
        private TextBox txtVerificarContrasena;
        private Button btnINICIARSESION;
        private Button btnREGISTRARME;
        private Label label7;
    }
}