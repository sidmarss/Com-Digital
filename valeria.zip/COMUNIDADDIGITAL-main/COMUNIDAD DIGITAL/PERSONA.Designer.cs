﻿namespace COMUNIDAD_DIGITAL
{
    partial class PERSONA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtUSUARIOOCORREO = new TextBox();
            txtNOMBRE = new TextBox();
            txtNUMEROTELEFONICO = new TextBox();
            txtCONTRASEÑA = new TextBox();
            txtVERIFICARCONTRASEÑA = new TextBox();
            btnINICIARSESION = new Button();
            btnREGISTRARME = new Button();
            label7 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(251, 19);
            label1.Name = "label1";
            label1.Size = new Size(556, 43);
            label1.TabIndex = 0;
            label1.Text = "BIENVENIDO A COMUNIDAD DIGITAL";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(95, 139);
            label2.Name = "label2";
            label2.Size = new Size(201, 28);
            label2.TabIndex = 1;
            label2.Text = "USUARIO O CORREO ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(453, 139);
            label3.Name = "label3";
            label3.Size = new Size(98, 28);
            label3.TabIndex = 2;
            label3.Text = "NOMBRE ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(758, 139);
            label4.Name = "label4";
            label4.Size = new Size(216, 28);
            label4.TabIndex = 3;
            label4.Text = "NUMERO TELEFONICO ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(95, 274);
            label5.Name = "label5";
            label5.Size = new Size(142, 28);
            label5.TabIndex = 4;
            label5.Text = "CONTRASEÑA ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(453, 274);
            label6.Name = "label6";
            label6.Size = new Size(238, 28);
            label6.TabIndex = 5;
            label6.Text = "VERIFICAR CONTRASEÑA ";
            // 
            // txtUSUARIOOCORREO
            // 
            txtUSUARIOOCORREO.Location = new Point(95, 179);
            txtUSUARIOOCORREO.Name = "txtUSUARIOOCORREO";
            txtUSUARIOOCORREO.Size = new Size(218, 27);
            txtUSUARIOOCORREO.TabIndex = 6;
            // 
            // txtNOMBRE
            // 
            txtNOMBRE.Location = new Point(453, 179);
            txtNOMBRE.Name = "txtNOMBRE";
            txtNOMBRE.Size = new Size(214, 27);
            txtNOMBRE.TabIndex = 7;
            txtNOMBRE.TextChanged += textBox2_TextChanged;
            // 
            // txtNUMEROTELEFONICO
            // 
            txtNUMEROTELEFONICO.Location = new Point(758, 179);
            txtNUMEROTELEFONICO.Name = "txtNUMEROTELEFONICO";
            txtNUMEROTELEFONICO.Size = new Size(216, 27);
            txtNUMEROTELEFONICO.TabIndex = 8;
            // 
            // txtCONTRASEÑA
            // 
            txtCONTRASEÑA.Location = new Point(95, 310);
            txtCONTRASEÑA.Name = "txtCONTRASEÑA";
            txtCONTRASEÑA.Size = new Size(218, 27);
            txtCONTRASEÑA.TabIndex = 9;
            txtCONTRASEÑA.TextChanged += textBox4_TextChanged;
            // 
            // txtVERIFICARCONTRASEÑA
            // 
            txtVERIFICARCONTRASEÑA.Location = new Point(453, 310);
            txtVERIFICARCONTRASEÑA.Name = "txtVERIFICARCONTRASEÑA";
            txtVERIFICARCONTRASEÑA.Size = new Size(214, 27);
            txtVERIFICARCONTRASEÑA.TabIndex = 10;
            // 
            // btnINICIARSESION
            // 
            btnINICIARSESION.BackColor = Color.LightSteelBlue;
            btnINICIARSESION.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnINICIARSESION.Location = new Point(251, 460);
            btnINICIARSESION.Name = "btnINICIARSESION";
            btnINICIARSESION.Size = new Size(199, 41);
            btnINICIARSESION.TabIndex = 11;
            btnINICIARSESION.Text = "INICIAR SESION ";
            btnINICIARSESION.UseVisualStyleBackColor = false;
            // 
            // btnREGISTRARME
            // 
            btnREGISTRARME.BackColor = Color.LightSteelBlue;
            btnREGISTRARME.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnREGISTRARME.Location = new Point(591, 460);
            btnREGISTRARME.Name = "btnREGISTRARME";
            btnREGISTRARME.Size = new Size(198, 41);
            btnREGISTRARME.TabIndex = 12;
            btnREGISTRARME.Text = "REGISTRARME ";
            btnREGISTRARME.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(433, 71);
            label7.Name = "label7";
            label7.Size = new Size(168, 31);
            label7.TabIndex = 13;
            label7.Text = "REGISTRARME ";
            // 
            // PERSONA
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1034, 586);
            Controls.Add(label7);
            Controls.Add(btnREGISTRARME);
            Controls.Add(btnINICIARSESION);
            Controls.Add(txtVERIFICARCONTRASEÑA);
            Controls.Add(txtCONTRASEÑA);
            Controls.Add(txtNUMEROTELEFONICO);
            Controls.Add(txtNOMBRE);
            Controls.Add(txtUSUARIOOCORREO);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "PERSONA";
            Text = "PERSONA";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtUSUARIOOCORREO;
        private TextBox txtNOMBRE;
        private TextBox txtNUMEROTELEFONICO;
        private TextBox txtCONTRASEÑA;
        private TextBox txtVERIFICARCONTRASEÑA;
        private Button btnINICIARSESION;
        private Button btnREGISTRARME;
        private Label label7;
    }
}