﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace COMUNIDAD_DIGITAL
{
    internal class Registro_Ciudadano
    {
        private string conexion = "server=localhost;user=root;password=root;database=comunidad_digital;"; // ajusta si usas contraseña

        public void Insertar(
            string nombre,
            string apellido_paterno,
            string apellido_materno,
            string sexo,
            DateTime fecha_nacimiento,
            string curp,
            int edad,
            string estado_civil,
            string localidad,
            string municipio,
            string estado,
            string nacionalidad,
            string calle,
            string colonia,
            string caracteristicas,
            string referencias,
            string telefono,
            string correo,
            string ocupacion)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                try
                {
                    conn.Open();

                    string query = @"INSERT INTO registro_ciudadano 
                        (nombre, apellido_paterno, apellido_materno, sexo, fecha_nacimiento, curp, edad, estado_civil, 
                         localidad, municipio, estado, nacionalidad, calle, colonia, caracteristicas_domicilio, referencias_domicilio, 
                         telefono, correo_electronico, ocupacion) 
                        VALUES 
                        (@nombre, @apellido_paterno, @apellido_materno, @sexo, @fecha_nacimiento, @curp, @edad, @estado_civil, 
                         @localidad, @municipio, @estado, @nacionalidad, @calle, @colonia, @caracteristicas, @referencias, 
                         @telefono, @correo, @ocupacion)";

                    MySqlCommand cmd = new MySqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@apellido_paterno", apellido_paterno);
                    cmd.Parameters.AddWithValue("@apellido_materno", apellido_materno);
                    cmd.Parameters.AddWithValue("@sexo", sexo);
                    cmd.Parameters.AddWithValue("@fecha_nacimiento", fecha_nacimiento.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@curp", curp);
                    cmd.Parameters.AddWithValue("@edad", edad);
                    cmd.Parameters.AddWithValue("@estado_civil", estado_civil);
                    cmd.Parameters.AddWithValue("@localidad", localidad);
                    cmd.Parameters.AddWithValue("@municipio", municipio);
                    cmd.Parameters.AddWithValue("@estado", estado);
                    cmd.Parameters.AddWithValue("@nacionalidad", nacionalidad);
                    cmd.Parameters.AddWithValue("@calle", calle);
                    cmd.Parameters.AddWithValue("@colonia", colonia);
                    cmd.Parameters.AddWithValue("@caracteristicas", caracteristicas);
                    cmd.Parameters.AddWithValue("@referencias", referencias);
                    cmd.Parameters.AddWithValue("@telefono", telefono);
                    cmd.Parameters.AddWithValue("@correo", correo);
                    cmd.Parameters.AddWithValue("@ocupacion", ocupacion);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("✅ Registro exitoso");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("❌ Error al registrar: " + ex.Message);
                }
            }
        }
    }
}
