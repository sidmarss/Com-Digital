﻿namespace COMUNIDAD_DIGITAL
{
    partial class CIUDADANO2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            numericUpDown1 = new NumericUpDown();
            label3 = new Label();
            textBox1 = new TextBox();
            label4 = new Label();
            checkedListBox1 = new CheckedListBox();
            label5 = new Label();
            checkedListBox2 = new CheckedListBox();
            label6 = new Label();
            label7 = new Label();
            checkedListBox3 = new CheckedListBox();
            textBox2 = new TextBox();
            label8 = new Label();
            textBox3 = new TextBox();
            label9 = new Label();
            textBox4 = new TextBox();
            label10 = new Label();
            textBox5 = new TextBox();
            label11 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            button1 = new Button();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(347, 31);
            label1.Name = "label1";
            label1.Size = new Size(276, 38);
            label1.TabIndex = 0;
            label1.Text = "REGISTRO MEDICO ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(378, 201);
            label2.Name = "label2";
            label2.Size = new Size(44, 20);
            label2.TabIndex = 1;
            label2.Text = "PESO";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(378, 224);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(70, 27);
            numericUpDown1.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(258, 201);
            label3.Name = "label3";
            label3.Size = new Size(78, 20);
            label3.TabIndex = 3;
            label3.Text = "ESTATURA";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(258, 224);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(78, 27);
            textBox1.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(54, 321);
            label4.Name = "label4";
            label4.Size = new Size(160, 20);
            label4.TabIndex = 5;
            label4.Text = "APOYO FUNCIONALES ";
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "LENTES", "AUDIFONOS", "BASTÓN", "ANDANDERA", "SILLA DE RUEDAS", "PRÓTESIS", "ÓRTESIS" });
            checkedListBox1.Location = new Point(54, 344);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(197, 158);
            checkedListBox1.TabIndex = 7;
            checkedListBox1.SelectedIndexChanged += checkedListBox1_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(347, 310);
            label5.Name = "label5";
            label5.Size = new Size(46, 20);
            label5.TabIndex = 8;
            label5.Text = "VICIO";
            // 
            // checkedListBox2
            // 
            checkedListBox2.FormattingEnabled = true;
            checkedListBox2.Items.AddRange(new object[] { "TABACO", "ALCOHOL", "DROGAS RECREATIVAS " });
            checkedListBox2.Location = new Point(347, 344);
            checkedListBox2.Name = "checkedListBox2";
            checkedListBox2.Size = new Size(185, 92);
            checkedListBox2.TabIndex = 9;
            checkedListBox2.SelectedIndexChanged += checkedListBox2_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(641, 321);
            label6.Name = "label6";
            label6.Size = new Size(185, 20);
            label6.TabIndex = 10;
            label6.Text = "ENFERMEDADES PREVIAS ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(48, 103);
            label7.Name = "label7";
            label7.Size = new Size(70, 20);
            label7.TabIndex = 11;
            label7.Text = "NOMBRE";
            // 
            // checkedListBox3
            // 
            checkedListBox3.FormattingEnabled = true;
            checkedListBox3.Items.AddRange(new object[] { "INFECCIOSAS", "ENDOCRINAS", "NEUROLOGICAS", "ONCOLOGICAS", "HEMATOLOGICAS", "PSIQUIATRICAS" });
            checkedListBox3.Location = new Point(641, 344);
            checkedListBox3.Name = "checkedListBox3";
            checkedListBox3.Size = new Size(176, 136);
            checkedListBox3.TabIndex = 12;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(48, 133);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(268, 27);
            textBox2.TabIndex = 13;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(48, 201);
            label8.Name = "label8";
            label8.Size = new Size(49, 20);
            label8.TabIndex = 14;
            label8.Text = "EDAD";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(48, 224);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(103, 27);
            textBox3.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(395, 103);
            label9.Name = "label9";
            label9.Size = new Size(211, 20);
            label9.TabIndex = 16;
            label9.Text = "NUMERO DE SEGURO SOCIAL ";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(395, 133);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(268, 27);
            textBox4.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(54, 525);
            label10.Name = "label10";
            label10.Size = new Size(127, 20);
            label10.TabIndex = 18;
            label10.Text = "OBSERVACIONES ";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(54, 548);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(221, 27);
            textBox5.TabIndex = 19;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(808, 157);
            label11.Name = "label11";
            label11.Size = new Size(86, 20);
            label11.TabIndex = 20;
            label11.Text = "GRAVEDAD";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(736, 180);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(66, 24);
            radioButton1.TabIndex = 21;
            radioButton1.TabStop = true;
            radioButton1.Text = "BAJO";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(808, 180);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(77, 24);
            radioButton2.TabIndex = 22;
            radioButton2.TabStop = true;
            radioButton2.Text = "MEDIO";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(891, 180);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(64, 24);
            radioButton3.TabIndex = 23;
            radioButton3.TabStop = true;
            radioButton3.Text = "ALTO";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackColor = Color.LightSteelBlue;
            button1.Location = new Point(360, 610);
            button1.Name = "button1";
            button1.Size = new Size(126, 40);
            button1.TabIndex = 24;
            button1.Text = "ATRAS";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.LightSteelBlue;
            button2.Location = new Point(537, 610);
            button2.Name = "button2";
            button2.Size = new Size(126, 40);
            button2.TabIndex = 25;
            button2.Text = "SIGUIENTE";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // CIUDADANO2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1035, 683);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label11);
            Controls.Add(textBox5);
            Controls.Add(label10);
            Controls.Add(textBox4);
            Controls.Add(label9);
            Controls.Add(textBox3);
            Controls.Add(label8);
            Controls.Add(textBox2);
            Controls.Add(checkedListBox3);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(checkedListBox2);
            Controls.Add(label5);
            Controls.Add(checkedListBox1);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(numericUpDown1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "CIUDADANO2";
            Text = "CIUDADANO2";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private NumericUpDown numericUpDown1;
        private Label label3;
        private TextBox textBox1;
        private Label label4;
        private CheckedListBox checkedListBox1;
        private Label label5;
        private CheckedListBox checkedListBox2;
        private Label label6;
        private Label label7;
        private CheckedListBox checkedListBox3;
        private TextBox textBox2;
        private Label label8;
        private TextBox textBox3;
        private Label label9;
        private TextBox textBox4;
        private Label label10;
        private TextBox textBox5;
        private Label label11;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private Button button1;
        private Button button2;
    }
}