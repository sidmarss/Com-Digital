﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMUNIDAD_DIGITAL
{
    public partial class FormRegistroC : Form
    {
        public FormRegistroC()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void DTPFechaN_ValueChanged(object sender, EventArgs e)
        {

        }

        private void FormRegistroC_Load(object sender, EventArgs e)
        {

        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            // Validar que ningún campo obligatorio esté vacío
            if (string.IsNullOrWhiteSpace(TxtName.Text) ||
                string.IsNullOrWhiteSpace(TxtApellidoP.Text) ||
                string.IsNullOrWhiteSpace(TxtApellidoM.Text) ||
                string.IsNullOrWhiteSpace(TxtCurp.Text) ||
                string.IsNullOrWhiteSpace(TxtEdad.Text) ||
                string.IsNullOrWhiteSpace(CBEstadoC.Text) ||
                string.IsNullOrWhiteSpace(TxtLocalidad.Text) ||
                string.IsNullOrWhiteSpace(TxtMunicipio.Text) ||
                string.IsNullOrWhiteSpace(TxtEstado.Text) ||
                string.IsNullOrWhiteSpace(TxtNacionalidad.Text) ||
                string.IsNullOrWhiteSpace(TxtCalle.Text) ||
                string.IsNullOrWhiteSpace(TxtColonia.Text) ||
                string.IsNullOrWhiteSpace(TxtCaracteristicasD.Text) ||
                string.IsNullOrWhiteSpace(TxtReferenciasD.Text) ||
                string.IsNullOrWhiteSpace(TxtTelefono.Text) ||
                string.IsNullOrWhiteSpace(TxtCorreo.Text) ||
                string.IsNullOrWhiteSpace(TxtOcupacion.Text) ||
                (!RbMujer.Checked && !RbHombre.Checked))
            {
                MessageBox.Show("❗ Por favor, llena todos los campos.", "Campos vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que edad sea número
            if (!int.TryParse(TxtEdad.Text, out int edad))
            {
                MessageBox.Show("❗ El campo Edad debe contener solo números.", "Edad inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar longitud de CURP
            if (TxtCurp.Text.Length != 18)
            {
                MessageBox.Show("❗ La CURP debe tener exactamente 18 caracteres.", "CURP inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar formato de correo
            if (!System.Text.RegularExpressions.Regex.IsMatch(TxtCorreo.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("❗ El correo electrónico no tiene un formato válido.", "Correo inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar fecha no futura
            if (DTPFechaN.Value.Date > DateTime.Now.Date)
            {
                MessageBox.Show("❗ La fecha de nacimiento no puede ser una fecha futura.", "Fecha inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar teléfono solo números
            if (!System.Text.RegularExpressions.Regex.IsMatch(TxtTelefono.Text, @"^\d+$"))
            {
                MessageBox.Show("❗ El teléfono debe contener solo números.", "Teléfono inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Registro_Ciudadano registro = new Registro_Ciudadano();

                registro.Insertar(
                    nombre: TxtName.Text.Trim(),
                    apellido_paterno: TxtApellidoP.Text.Trim(),
                    apellido_materno: TxtApellidoM.Text.Trim(),
                    sexo: RbMujer.Checked ? "Mujer" : "Hombre",
                    fecha_nacimiento: DTPFechaN.Value,
                    curp: TxtCurp.Text.Trim().ToUpper(),
                    edad: edad,
                    estado_civil: CBEstadoC.Text.Trim(),
                    localidad: TxtLocalidad.Text.Trim(),
                    municipio: TxtMunicipio.Text.Trim(),
                    estado: TxtEstado.Text.Trim(),
                    nacionalidad: TxtNacionalidad.Text.Trim(),
                    calle: TxtCalle.Text.Trim(),
                    colonia: TxtColonia.Text.Trim(),
                    caracteristicas: TxtCaracteristicasD.Text.Trim(),
                    referencias: TxtReferenciasD.Text.Trim(),
                    telefono: TxtTelefono.Text.Trim(),
                    correo: TxtCorreo.Text.Trim(),
                    ocupacion: TxtOcupacion.Text.Trim()
                );

                MessageBox.Show("✅ Registro guardado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LimpiarFormulario();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❗ Ocurrió un error al guardar el registro: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarFormulario()
        {
            TxtName.Clear();
            TxtApellidoP.Clear();
            TxtApellidoM.Clear();
            TxtCurp.Clear();
            TxtEdad.Clear();
            CBEstadoC.SelectedIndex = -1;
            TxtLocalidad.Clear();
            TxtMunicipio.Clear();
            TxtEstado.Clear();
            TxtNacionalidad.Clear();
            TxtCalle.Clear();
            TxtColonia.Clear();
            TxtCaracteristicasD.Clear();
            TxtReferenciasD.Clear();
            TxtTelefono.Clear();
            TxtCorreo.Clear();
            TxtOcupacion.Clear();
            RbMujer.Checked = false;
            RbHombre.Checked = false;
            DTPFechaN.Value = DateTime.Now;
        }
    }
}

