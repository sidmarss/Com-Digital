﻿namespace COMUNIDAD_DIGITAL
{
    partial class FormRegistroC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            TxtName = new TextBox();
            TxtApellidoP = new TextBox();
            TxtApellidoM = new TextBox();
            label5 = new Label();
            TxtLocalidad = new TextBox();
            label6 = new Label();
            TxtEstado = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            TxtEdad = new TextBox();
            CBEstadoC = new ComboBox();
            label10 = new Label();
            TxtCurp = new TextBox();
            RbMujer = new RadioButton();
            RbHombre = new RadioButton();
            DTPFechaN = new DateTimePicker();
            label11 = new Label();
            label12 = new Label();
            TxtMunicipio = new TextBox();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            TxtNacionalidad = new TextBox();
            label16 = new Label();
            label17 = new Label();
            label19 = new Label();
            label20 = new Label();
            TxtCalle = new TextBox();
            TxtColonia = new TextBox();
            TxtCaracteristicasD = new TextBox();
            TxtReferenciasD = new TextBox();
            label21 = new Label();
            label22 = new Label();
            TxtTelefono = new TextBox();
            TxtCorreo = new TextBox();
            label18 = new Label();
            TxtOcupacion = new TextBox();
            BtnAtras = new Button();
            BtnSiguiente = new Button();
            BtnGuardar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(348, 9);
            label1.Name = "label1";
            label1.Size = new Size(340, 38);
            label1.TabIndex = 0;
            label1.Text = "REGISTRO CIUDADANO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(68, 106);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 1;
            label2.Text = "NOMBRE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(296, 106);
            label3.Name = "label3";
            label3.Size = new Size(142, 20);
            label3.TabIndex = 2;
            label3.Text = "APELLIDO PATERNO";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(536, 106);
            label4.Name = "label4";
            label4.Size = new Size(152, 20);
            label4.TabIndex = 3;
            label4.Text = "APELLIDO MATERNO ";
            label4.Click += label4_Click;
            // 
            // TxtName
            // 
            TxtName.Location = new Point(68, 129);
            TxtName.Name = "TxtName";
            TxtName.Size = new Size(190, 27);
            TxtName.TabIndex = 4;
            // 
            // TxtApellidoP
            // 
            TxtApellidoP.Location = new Point(296, 129);
            TxtApellidoP.Name = "TxtApellidoP";
            TxtApellidoP.Size = new Size(190, 27);
            TxtApellidoP.TabIndex = 5;
            // 
            // TxtApellidoM
            // 
            TxtApellidoM.Location = new Point(536, 129);
            TxtApellidoM.Name = "TxtApellidoM";
            TxtApellidoM.Size = new Size(190, 27);
            TxtApellidoM.TabIndex = 6;
            TxtApellidoM.TextChanged += textBox3_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(39, 325);
            label5.Name = "label5";
            label5.Size = new Size(166, 20);
            label5.TabIndex = 7;
            label5.Text = "LOCALIDAD O CIUDAD ";
            // 
            // TxtLocalidad
            // 
            TxtLocalidad.Location = new Point(39, 357);
            TxtLocalidad.Name = "TxtLocalidad";
            TxtLocalidad.Size = new Size(190, 27);
            TxtLocalidad.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(489, 325);
            label6.Name = "label6";
            label6.Size = new Size(64, 20);
            label6.TabIndex = 9;
            label6.Text = "ESTADO";
            // 
            // TxtEstado
            // 
            TxtEstado.Location = new Point(489, 357);
            TxtEstado.Name = "TxtEstado";
            TxtEstado.Size = new Size(190, 27);
            TxtEstado.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(773, 184);
            label7.Name = "label7";
            label7.Size = new Size(101, 20);
            label7.TabIndex = 11;
            label7.Text = "ESTADO CIVIL";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(847, 106);
            label8.Name = "label8";
            label8.Size = new Size(45, 20);
            label8.TabIndex = 12;
            label8.Text = "SEXO";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(618, 184);
            label9.Name = "label9";
            label9.Size = new Size(49, 20);
            label9.TabIndex = 15;
            label9.Text = "EDAD";
            // 
            // TxtEdad
            // 
            TxtEdad.Location = new Point(618, 207);
            TxtEdad.Name = "TxtEdad";
            TxtEdad.Size = new Size(94, 27);
            TxtEdad.TabIndex = 16;
            // 
            // CBEstadoC
            // 
            CBEstadoC.FormattingEnabled = true;
            CBEstadoC.Items.AddRange(new object[] { "SOLTERO", "CASADO", "VIUDO", "DIVORCIADO", "UNION LIBRE " });
            CBEstadoC.Location = new Point(773, 209);
            CBEstadoC.Name = "CBEstadoC";
            CBEstadoC.Size = new Size(151, 28);
            CBEstadoC.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(403, 184);
            label10.Name = "label10";
            label10.Size = new Size(45, 20);
            label10.TabIndex = 18;
            label10.Text = "CURP";
            // 
            // TxtCurp
            // 
            TxtCurp.Location = new Point(403, 207);
            TxtCurp.Name = "TxtCurp";
            TxtCurp.Size = new Size(190, 27);
            TxtCurp.TabIndex = 19;
            // 
            // RbMujer
            // 
            RbMujer.AutoSize = true;
            RbMujer.Location = new Point(783, 129);
            RbMujer.Name = "RbMujer";
            RbMujer.Size = new Size(75, 24);
            RbMujer.TabIndex = 21;
            RbMujer.TabStop = true;
            RbMujer.Text = "MUJER";
            RbMujer.UseVisualStyleBackColor = true;
            // 
            // RbHombre
            // 
            RbHombre.AutoSize = true;
            RbHombre.Location = new Point(889, 129);
            RbHombre.Name = "RbHombre";
            RbHombre.Size = new Size(91, 24);
            RbHombre.TabIndex = 22;
            RbHombre.TabStop = true;
            RbHombre.Text = "HOMBRE";
            RbHombre.UseVisualStyleBackColor = true;
            // 
            // DTPFechaN
            // 
            DTPFechaN.Checked = false;
            DTPFechaN.Location = new Point(68, 207);
            DTPFechaN.Name = "DTPFechaN";
            DTPFechaN.Size = new Size(277, 27);
            DTPFechaN.TabIndex = 23;
            DTPFechaN.ValueChanged += DTPFechaN_ValueChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(68, 184);
            label11.Name = "label11";
            label11.Size = new Size(173, 20);
            label11.TabIndex = 24;
            label11.Text = "FECHA DE NACIMIENTO ";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(262, 325);
            label12.Name = "label12";
            label12.Size = new Size(83, 20);
            label12.TabIndex = 25;
            label12.Text = "MUNICIPIO";
            // 
            // TxtMunicipio
            // 
            TxtMunicipio.Location = new Point(262, 357);
            TxtMunicipio.Name = "TxtMunicipio";
            TxtMunicipio.Size = new Size(190, 27);
            TxtMunicipio.TabIndex = 26;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(28, 64);
            label13.Name = "label13";
            label13.Size = new Size(207, 28);
            label13.TabIndex = 27;
            label13.Text = "DATOS PERSONALES";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(28, 273);
            label14.Name = "label14";
            label14.Size = new Size(116, 28);
            label14.TabIndex = 28;
            label14.Text = "DOMICILIO";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(724, 325);
            label15.Name = "label15";
            label15.Size = new Size(118, 20);
            label15.TabIndex = 29;
            label15.Text = "NACIONALIDAD";
            // 
            // TxtNacionalidad
            // 
            TxtNacionalidad.Location = new Point(724, 357);
            TxtNacionalidad.Name = "TxtNacionalidad";
            TxtNacionalidad.Size = new Size(190, 27);
            TxtNacionalidad.TabIndex = 30;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(39, 413);
            label16.Name = "label16";
            label16.Size = new Size(50, 20);
            label16.TabIndex = 31;
            label16.Text = "CALLE";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(204, 413);
            label17.Name = "label17";
            label17.Size = new Size(263, 20);
            label17.TabIndex = 32;
            label17.Text = "COLONIA,REGION O SUPERMANZANA";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(498, 413);
            label19.Name = "label19";
            label19.Size = new Size(240, 20);
            label19.TabIndex = 34;
            label19.Text = "CARACTERISTICAS DEL DOMICILIO";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(811, 413);
            label20.Name = "label20";
            label20.Size = new Size(201, 20);
            label20.TabIndex = 35;
            label20.Text = "REFERENCIAS DE DOMICILIO";
            // 
            // TxtCalle
            // 
            TxtCalle.Location = new Point(39, 453);
            TxtCalle.Name = "TxtCalle";
            TxtCalle.Size = new Size(134, 27);
            TxtCalle.TabIndex = 36;
            // 
            // TxtColonia
            // 
            TxtColonia.Location = new Point(204, 453);
            TxtColonia.Name = "TxtColonia";
            TxtColonia.Size = new Size(263, 27);
            TxtColonia.TabIndex = 37;
            // 
            // TxtCaracteristicasD
            // 
            TxtCaracteristicasD.Location = new Point(507, 453);
            TxtCaracteristicasD.Name = "TxtCaracteristicasD";
            TxtCaracteristicasD.Size = new Size(240, 27);
            TxtCaracteristicasD.TabIndex = 38;
            // 
            // TxtReferenciasD
            // 
            TxtReferenciasD.Location = new Point(811, 453);
            TxtReferenciasD.Name = "TxtReferenciasD";
            TxtReferenciasD.Size = new Size(201, 27);
            TxtReferenciasD.TabIndex = 39;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(39, 553);
            label21.Name = "label21";
            label21.Size = new Size(80, 20);
            label21.TabIndex = 40;
            label21.Text = "TELEFONO";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(277, 553);
            label22.Name = "label22";
            label22.Size = new Size(165, 20);
            label22.TabIndex = 41;
            label22.Text = "CORREO ELECTRONICO";
            // 
            // TxtTelefono
            // 
            TxtTelefono.Location = new Point(39, 586);
            TxtTelefono.Name = "TxtTelefono";
            TxtTelefono.Size = new Size(190, 27);
            TxtTelefono.TabIndex = 42;
            // 
            // TxtCorreo
            // 
            TxtCorreo.Location = new Point(277, 586);
            TxtCorreo.Name = "TxtCorreo";
            TxtCorreo.Size = new Size(227, 27);
            TxtCorreo.TabIndex = 43;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(562, 553);
            label18.Name = "label18";
            label18.Size = new Size(91, 20);
            label18.TabIndex = 44;
            label18.Text = "OCUPACIÓN";
            // 
            // TxtOcupacion
            // 
            TxtOcupacion.Location = new Point(562, 586);
            TxtOcupacion.Name = "TxtOcupacion";
            TxtOcupacion.Size = new Size(227, 27);
            TxtOcupacion.TabIndex = 45;
            // 
            // BtnAtras
            // 
            BtnAtras.BackColor = Color.LightSteelBlue;
            BtnAtras.Location = new Point(188, 654);
            BtnAtras.Name = "BtnAtras";
            BtnAtras.Size = new Size(132, 41);
            BtnAtras.TabIndex = 46;
            BtnAtras.Text = "ATRAS";
            BtnAtras.UseVisualStyleBackColor = false;
            // 
            // BtnSiguiente
            // 
            BtnSiguiente.BackColor = Color.LightSteelBlue;
            BtnSiguiente.Location = new Point(781, 650);
            BtnSiguiente.Name = "BtnSiguiente";
            BtnSiguiente.Size = new Size(133, 45);
            BtnSiguiente.TabIndex = 47;
            BtnSiguiente.Text = "SIGUIENTE";
            BtnSiguiente.UseVisualStyleBackColor = false;
            // 
            // BtnGuardar
            // 
            BtnGuardar.BackColor = Color.LightSteelBlue;
            BtnGuardar.Location = new Point(480, 654);
            BtnGuardar.Name = "BtnGuardar";
            BtnGuardar.Size = new Size(132, 41);
            BtnGuardar.TabIndex = 48;
            BtnGuardar.Text = "GUARDAR";
            BtnGuardar.UseVisualStyleBackColor = false;
            BtnGuardar.Click += BtnGuardar_Click;
            // 
            // FormRegistroC
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1036, 724);
            Controls.Add(BtnGuardar);
            Controls.Add(BtnSiguiente);
            Controls.Add(BtnAtras);
            Controls.Add(TxtOcupacion);
            Controls.Add(label18);
            Controls.Add(TxtCorreo);
            Controls.Add(TxtTelefono);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(TxtReferenciasD);
            Controls.Add(TxtCaracteristicasD);
            Controls.Add(TxtColonia);
            Controls.Add(TxtCalle);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(TxtNacionalidad);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(TxtMunicipio);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(DTPFechaN);
            Controls.Add(RbHombre);
            Controls.Add(RbMujer);
            Controls.Add(TxtCurp);
            Controls.Add(label10);
            Controls.Add(CBEstadoC);
            Controls.Add(TxtEdad);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(TxtEstado);
            Controls.Add(label6);
            Controls.Add(TxtLocalidad);
            Controls.Add(label5);
            Controls.Add(TxtApellidoM);
            Controls.Add(TxtApellidoP);
            Controls.Add(TxtName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormRegistroC";
            Text = "CIUDADANO";
            Load += FormRegistroC_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox TxtName;
        private TextBox TxtApellidoP;
        private TextBox TxtApellidoM;
        private Label label5;
        private TextBox TxtLocalidad;
        private Label label6;
        private TextBox TxtEstado;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox TxtEdad;
        private ComboBox CBEstadoC;
        private Label label10;
        private TextBox TxtCurp;
        private RadioButton RbMujer;
        private RadioButton RbHombre;
        private DateTimePicker DTPFechaN;
        private Label label11;
        private Label label12;
        private TextBox TxtMunicipio;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox TxtNacionalidad;
        private Label label16;
        private Label label17;
        private Label label19;
        private Label label20;
        private TextBox TxtCalle;
        private TextBox TxtColonia;
        private TextBox TxtCaracteristicasD;
        private TextBox TxtReferenciasD;
        private Label label21;
        private Label label22;
        private TextBox TxtTelefono;
        private TextBox TxtCorreo;
        private Label label18;
        private TextBox TxtOcupacion;
        private Button BtnAtras;
        private Button BtnSiguiente;
        private Button BtnGuardar;
    }
}