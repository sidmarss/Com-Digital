namespace COMUNIDAD_DIGITAL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnREGISTRARME_Click(object sender, EventArgs e)
        {
            FormRegistroC ventanaCiudadano = new FormRegistroC(); // Crea una instancia del formulario
            ventanaCiudadano.Show(); // Abre la ventana CIUDADANO
            this.Hide();
        }
    }
}
