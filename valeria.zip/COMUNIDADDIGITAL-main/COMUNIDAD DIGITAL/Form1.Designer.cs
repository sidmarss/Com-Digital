﻿namespace COMUNIDAD_DIGITAL
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtCORREO = new TextBox();
            txtCONTRASEÑA = new TextBox();
            btnINICIOSESION = new Button();
            btnREGISTRARME = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightSteelBlue;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ImageAlign = ContentAlignment.TopCenter;
            label1.Location = new Point(239, 27);
            label1.Margin = new Padding(8, 0, 8, 0);
            label1.Name = "label1";
            label1.Size = new Size(564, 43);
            label1.TabIndex = 0;
            label1.Text = "BIENVENIDO A COMUNIDAD DIGITAL ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(431, 116);
            label2.Name = "label2";
            label2.Size = new Size(175, 28);
            label2.TabIndex = 1;
            label2.Text = "INICIO DE SESION ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(181, 214);
            label3.Name = "label3";
            label3.Size = new Size(92, 28);
            label3.TabIndex = 2;
            label3.Text = "CORREO ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(181, 313);
            label4.Name = "label4";
            label4.Size = new Size(137, 28);
            label4.TabIndex = 3;
            label4.Text = "CONTRASEÑA";
            label4.Click += label4_Click;
            // 
            // txtCORREO
            // 
            txtCORREO.Location = new Point(341, 201);
            txtCORREO.Name = "txtCORREO";
            txtCORREO.Size = new Size(381, 48);
            txtCORREO.TabIndex = 4;
            // 
            // txtCONTRASEÑA
            // 
            txtCONTRASEÑA.Location = new Point(341, 295);
            txtCONTRASEÑA.Name = "txtCONTRASEÑA";
            txtCONTRASEÑA.Size = new Size(381, 48);
            txtCONTRASEÑA.TabIndex = 5;
            // 
            // btnINICIOSESION
            // 
            btnINICIOSESION.BackColor = Color.LightSteelBlue;
            btnINICIOSESION.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnINICIOSESION.Location = new Point(387, 425);
            btnINICIOSESION.Name = "btnINICIOSESION";
            btnINICIOSESION.Size = new Size(299, 39);
            btnINICIOSESION.TabIndex = 6;
            btnINICIOSESION.Text = "INICIAR SESION ";
            btnINICIOSESION.UseVisualStyleBackColor = false;
            // 
            // btnREGISTRARME
            // 
            btnREGISTRARME.BackColor = Color.LightSteelBlue;
            btnREGISTRARME.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnREGISTRARME.Location = new Point(387, 509);
            btnREGISTRARME.Name = "btnREGISTRARME";
            btnREGISTRARME.Size = new Size(299, 42);
            btnREGISTRARME.TabIndex = 7;
            btnREGISTRARME.Text = "REGISTRARME ";
            btnREGISTRARME.UseVisualStyleBackColor = false;
            btnREGISTRARME.Click += btnREGISTRARME_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(20F, 40F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1035, 616);
            Controls.Add(btnREGISTRARME);
            Controls.Add(btnINICIOSESION);
            Controls.Add(txtCONTRASEÑA);
            Controls.Add(txtCORREO);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 19.8000011F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ActiveCaptionText;
            Margin = new Padding(8, 6, 8, 6);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtCORREO;
        private TextBox txtCONTRASEÑA;
        private Button btnINICIOSESION;
        private Button btnREGISTRARME;
    }
}
